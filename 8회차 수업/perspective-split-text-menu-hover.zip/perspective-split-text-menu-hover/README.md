# Perspective Split Text Menu Hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/bosworthco/pen/RjBvgw](https://codepen.io/bosworthco/pen/RjBvgw).

Inspired by the menu on https://www.cssdesignawards.com/woty2017/

This is a great trick for a much more immersive menu.